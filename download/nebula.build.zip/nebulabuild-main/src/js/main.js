// show menu
// import { showMenu } from "./modules/showMenu";
// showMenu();

// scroll header
// import { headerScroll } from "./modules/headerScroll";
// headerScroll();

// show scroll up
// import { showScrollUp } from "./modules/showScrollUp";
// showScrollUp();

// slider
// import { slider } from "./modules/swiper";
// slider();

// show accordeon
// import { showAccordeon } from "./modules/showAccordeon";
// showAccordeon();

// lightbox
// import { lightboxCustom } from "./modules/lightboxCustom";
// lightboxCustom();

// gsap
// import { gsap } from "gsap/gsap-core";
// gsap();

// scroll reveal
// import { scrRev } from "./modules/ScrollReveal";
// scrRev();