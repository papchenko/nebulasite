import { gsap } from "gsap";

export const gsapAnim = () => {
    // for examples
    // gsap.from('.', {duration: 4.5, opacity: 0, ease: 'power2.in'});
    // gsap.to(".", {rotation: 360, y: 100, duration: 1});
    // gsap.from('.', {x: -100, duration: 1, opacity: 0, ease: 'power1.in'});
}